﻿using System;
using System.Data.SqlClient;
using System.Data;

namespace Capgemini.GreatOutdoors.DataAccessLayer
{
    public class DAL
    {
        private SqlConnection sqlConn;
        public string Error;
        public DAL()
        {
            try
            {
                sqlConn = new SqlConnection("Data Source=ndamssql\\sqlilearn;Initial Catalog=&quot;13th Aug CLoud PT Immersive&quot;;Persist Security Info=True;User ID=sqluser;Password=sqluser");
                // Capgemini.GreatOutdoors.DataAccessLayer.Properties.Settings.dbCon);// );
            }
            catch (Exception ex)
            {
                Error = ex.Message;
            }
        }

        bool CheckConnection()
        {

            try
            {
                if (sqlConn.State != ConnectionState.Open)
                    sqlConn.Open();
                return true;
            }
            catch (Exception ex)
            {
                Error = ex.Message;
                return false;
            }

        }

        public int ExecuteNonQuery(SqlCommand sqlCmd)
        {
            sqlCmd.Connection = sqlConn;

            if (CheckConnection() == false)
            {
                return -1;
            }
            try
            {
                int i = sqlCmd.ExecuteNonQuery();
                CloseConnection();
                return i;
            }
            catch (Exception ex)
            {
                Error = ex.Message;
                return -1;
            }
        }

        public DataSet RetriveDataSet(SqlCommand sqlCmd)
        {
            sqlCmd.Connection = sqlConn;
            if (CheckConnection() == false)
            {
                return null;
            }
            DataSet dtSet = new DataSet();
            try
            {
                SqlDataAdapter sqlAdp = new SqlDataAdapter(sqlCmd);
                sqlAdp.Fill(dtSet);
                CloseConnection();
                return dtSet;
            }
            catch (Exception ex)
            {
                Error = ex.Message;
                return null;
            }
        }

        public SqlDataReader RetriveDataReader(SqlCommand sqlCmd)
        {
            sqlCmd.Connection = sqlConn;
            if (CheckConnection() == false)
            {
                return null;
            }
            try
            {
                return sqlCmd.ExecuteReader();
            }
            catch (Exception ex)
            {
                Error = ex.Message;
                return null;
            }
        }

        public void CloseConnection()
        {
            try
            {
                sqlConn.Close();
            }
            catch (Exception)
            {
                //
            }
        }
    }
}