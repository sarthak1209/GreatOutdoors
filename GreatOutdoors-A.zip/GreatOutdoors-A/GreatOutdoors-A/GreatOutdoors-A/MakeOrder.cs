﻿using Capgemini.GreatOutdoors.BusinessLayer;
using Capgemini.GreatOutdoors.Contracts.BLContracts;
using Capgemini.GreatOutdoors.Entities;
using Capgemini.GreatOutdoors.Exceptions;
using GreatOutdoors.BusinessLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Capgemini.GreatOutdoors.PresentationLayer
{
    class MakeOrder
    {
        public static async Task ViewProducts()
        {
            try
            {

                using (IProductBL productBL = new ProductBL())
                {
                    //Get and display list of products
                    List<Product> products = await productBL.GetAllProductsBL();
                    Console.WriteLine("PRODUCTS : ");
                    Console.WriteLine("#\tProduct Name\tColour\tPrice\tSpecifications");
                    if (products != null && products?.Count > 0)
                    {
                        Console.WriteLine(".......................");
                        int serial = 0;
                        foreach (var product in products)
                        {
                            serial++;
                            Console.WriteLine($"{serial}\t{product.ProductName}\t{product.ProductColour}\t{product.SellingPrice}\t{product.ProductTechSpecs}");
                        }
                    }
                    using (IOrdersBL orderBL = new OrderBL())
                    {
                        // Create new order to get orderID
                        Order order = new Order();
                        (bool orderConfirmed, Guid Id) = await orderBL.AddOrderBL(order);


                        using (IOrderDetailsBL orderDetailsBL = new OrderDetailsBL())
                        {
                            bool replyValid = true;
                            int serial = 0;
                            do
                            {
                                // Add order details to each order
                                OrderDetail currentProduct = new OrderDetail();
                                currentProduct.OrderDetailID = Guid.NewGuid();
                                currentProduct.OrderID = Id;
                                Console.WriteLine("Select the product : ");
                                currentProduct.ProductID = products[int.Parse(Console.ReadLine()) - 1].ProductID;
                                Console.WriteLine("Enter Quantity : ");
                                currentProduct.Quantity = int.Parse(Console.ReadLine());
                                using (IAddressBL addresses = new AddressBL())
                                {
                                    IRetailerBL currRetailerBL = new RetailerBL();
                                    Retailer retailer = await currRetailerBL.GetRetailerByEmailAndPasswordBL(CommonData.CurrentUser.Email, CommonData.CurrentUser.Password);

                                    Guid currentRetailerID = retailer.RetailerID;
                                    List<Address> storedAddresses = await addresses.GetAddressByRetailerIDBL(currentRetailerID);
                                    int addserial = 0;
                                    foreach (var item in storedAddresses)
                                    {
                                        addserial++;
                                        Console.WriteLine($"{addserial}\t{item.Line1}\t{item.Line2}\t{item.City}\t{item.State}\t{item.Pincode}");
                                    }
                                    Console.WriteLine(" Select Address for the product : ");
                                    int chosenAddress = int.Parse(Console.ReadLine());
                                    currentProduct.AddressID = storedAddresses[chosenAddress - 1].AddressID;
                                }
                               
                                //currentProduct.
                                currentProduct.UnitPrice = await orderDetailsBL.CalculateDiscountPriceBL(currentProduct.ProductID);
                                currentProduct.TotalPrice = orderDetailsBL.CalculateTotalPriceBL(currentProduct);
                                bool isOrderAdded = await orderDetailsBL.AddOrderDetailsBL(currentProduct);
                                serial++;
                                Console.WriteLine("You want to add another Product(Y/N) : ");
                                string replyConsole = Console.ReadLine();
                                if ((replyConsole.ToLower()).Equals("y"))
                                    replyValid = true;
                                else if ((replyConsole.ToLower()).Equals("n"))
                                    replyValid = false;
                                else
                                    Console.WriteLine("Invalid choice");
                            } while (replyValid);

                            List<OrderDetail> viewCart = await orderDetailsBL.GetOrderDetailsByOrderIDBL(Id);
                            int print = 0;
                            foreach (var item in viewCart)
                            {
                                print++;
                                Console.WriteLine($"{print}\t{item.ProductID}\t{item.Quantity}\t{item.UnitPrice}\t{item.TotalPrice}\t{item.Status}\t{item.AddressID}");
                            }
                            Order fetch = await orderBL.GetOrderByOrderIDBL(Id);
                            List<OrderDetail> confirm = await orderDetailsBL.GetOrderDetailsByOrderIDBL(Id);
                            fetch.TotalAmount = await orderDetailsBL.AmountPayable(confirm);

                            // Displaying total amount
                            Console.WriteLine($"Total Amount to be paid: {fetch.TotalAmount}");
                            //Checking for payment
                            Console.WriteLine("You want to make payment(Y/N) ?");
                            string makePayment = (Console.ReadLine()).ToLower();

                            // Confirming order on payment
                            if (makePayment == "y")
                            {

                                fetch.TotalQuantity = await orderDetailsBL.TotalQuantity(confirm);

                                fetch.TotalAmount = await orderDetailsBL.AmountPayable(confirm);

                                fetch.OrderDateTime = DateTime.Now;

                                fetch.ChannelOfSale = Channel.Online;

                                foreach (var item in viewCart)
                                {
                                    if (item.OrderID == Id)
                                        orderDetailsBL.UpdateOrderDetailStatusBL(Id, item.ProductID, ProductStatus.UnderProcessing);
                                }

                                // fetching current retailer details
                                using (IRetailerBL currRetailerBL = new RetailerBL())
                                {
                                    Retailer ret = await currRetailerBL.GetRetailerByEmailAndPasswordBL(CommonData.CurrentUser.Email, CommonData.CurrentUser.Password);
                                    fetch.RetailerID = ret.RetailerID;
                                }
                                List<OrderDetail> viewCartAgain = await orderDetailsBL.GetOrderDetailsByOrderIDBL(Id);
                                int printagain = 0;
                                foreach (var item in viewCartAgain)
                                {
                                    printagain++;
                                    Console.WriteLine($"{print}\t{item.ProductID}\t{item.Quantity}\t{item.UnitPrice}\t{item.TotalPrice}\t{item.Status}\t{item.AddressID}");
                                }
                                Console.WriteLine("Thank you for shopping with us.");


                            }


                            if (makePayment == "n")
                            {
                                // Delete order from list
                                List<OrderDetail> delete = await orderDetailsBL.GetOrderDetailsByOrderIDBL(Id);
                                int count = delete.Count();
                                while (serial > 0)
                                {
                                    count--;
                                    await orderDetailsBL.DeleteOrderDetailsBL(delete[count].OrderID, delete[count].ProductID);
                                    serial--;

                                }
                                Console.WriteLine("Thank you for shopping with us.");
                                await orderBL.DeleteOrderByOrderID(Id);

                            }
                        }
                    }
                }
            }
            catch (GreatOutdoorsException ex)
            {
                ExceptionLogger.LogException(ex);
                Console.WriteLine(ex.Message);
            }
        }

    }
}

