﻿using Capgemini.GreatOutdoors.Helpers.ValidationAttributes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GreatOutdoors.Entities
{
    /// <summary>
    /// Interface for State Entity
    /// </summary>
    public interface IState
    {
        List<String> StateList { get; set; }
    }

    /// <summary>
    /// Represents State
    /// </summary>
    public class State
    {
        /* Auto-Implemented Properties */
        [Required("State cannot be empty")]
        List<String> StateList { get; set; }

        //Array of States in India
        string[] States = { "Andhra Pradesh", "Arunachal Pradesh", "Assam", "Bihar", "Chhattisgarh", "Goa", "Gujarat", "Haryana", "Himachal Pradesh", "Jammu and Kashmir", "Jharkhand", "Karnataka", "Kerala", "Madhya Pradesh", "Maharashtra", "Manipur", "Meghalaya", "Mizoram", "Nagaland", "Odisha", "Punjab", "Rajasthan", "Sikkim", "Tamil Nadu", "Telangana", "Tripura", "Uttar Pradesh", "Uttarakhand", "West Bengal", "Andaman and Nicobar Islands", "Chandigarh", "Dadra and Nagar Haveli", "Daman and Diu", "Lakshadweep", "National Capital Territory of Delhi", "Puducherry " };

        /*Constructor*/
        public State()
        {
            StateList = new List<string>(States);
        }
    }
}
