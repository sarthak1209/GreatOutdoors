﻿using GreatOutdoors.Entities;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;

namespace GreatOutdoors.WCFService
{
    
    public class Service1 : IService1
    {
        public List<ReturnDetailsDataContract> GetReturnDetailsByRetailerIDDAL(Guid RetailerID)
        {
            List<ReturnDetailsDataContract> searchReturnDetails = new List<ReturnDetailsDataContract>();
            
                DbProviderFactory factory = DbProviderFactories.GetFactory(System.Configuration.ConfigurationManager.ConnectionStrings["GOConnectionString"].ProviderName);


                DbConnection connection = factory.CreateConnection();

                connection.ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["GOConnectionString"].ConnectionString;

                //Create command
                DbCommand command = connection.CreateCommand();
                command.CommandText = "[13th Aug CLoud PT Immersive].TeamA.GetReturnDetailsByRetailerID";
                command.Connection = connection;
                command.CommandType = System.Data.CommandType.StoredProcedure;

                //Create parameters
                DbParameter p1 = command.CreateParameter();
                p1.ParameterName = "@retailerID";
                p1.Value = RetailerID;
                p1.DbType = System.Data.DbType.Guid;
                command.Parameters.Add(p1);

                //Create adapter
                DbDataAdapter adapter = factory.CreateDataAdapter();
                adapter.SelectCommand = command;

                //Create dataset
                DataSet ds = new DataSet();
                //Execute
                adapter.Fill(ds);

                //Convert datatable to collection
                searchReturnDetails =
                    ds.Tables[0]
                    .AsEnumerable()
                    .Select(p => new ReturnDetailsDataContract()
                    {
                        ReturnDetailID = p.Field<Guid>("ReturnDetailID"),
                        ReturnID = p.Field<Guid>("ReturnID"),
                        ProductID = p.Field<Guid>("ProductID"),
                        Quantity = p.Field<int>("Quantity"),
                        ReasonOfReturn = p.Field<string>("ReasonOfReturn"),
                        UnitPrice = p.Field<decimal>("UnitPrice"),
                        TotalPrice = p.Field<decimal>("TotalPrice"),
                        AddressID = p.Field<Guid>("AddressID")
                    }).ToList();
            
           

            return searchReturnDetails;
        }



        public Address GetAddressByAddressID(Guid searchAddressID)
        {
            Address matchingAddress = new Address();
           
            //Find Product based on searchProductID
                //Create factory
                DbProviderFactory factory = DbProviderFactories.GetFactory(System.Configuration.ConfigurationManager.ConnectionStrings["GOConnectionString"].ProviderName);
                //Create connection
                DbConnection connection = factory.CreateConnection();
                connection.ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["GOConnectionString"].ConnectionString;
                //Create command
                DbCommand command = connection.CreateCommand();
                command.CommandText = "TeamA.GetAddressByAddressID";
                command.Connection = connection;
                command.CommandType = System.Data.CommandType.StoredProcedure;
                //Create parameters
                DbParameter p1 = command.CreateParameter();
                p1.ParameterName = "@AddressID";
                p1.Value = searchAddressID;
                p1.DbType = System.Data.DbType.Guid;
                command.Parameters.Add(p1);
                //Create adapter
                DbDataAdapter adapter = factory.CreateDataAdapter();
                adapter.SelectCommand = command;
                //Create dataset
                DataSet ds = new DataSet();
                //Execute
                adapter.Fill(ds);
                //Convert datatable to collection
                matchingAddress = ds.Tables[0]
                    .AsEnumerable()
                    .Select(p => new Address()
                    {
                        AddressID = p.Field<Guid>("AddressID"),
                        RetailerID = p.Field<Guid>("RetailerID"),
                        Line1 = p.Field<string>("Line1"),
                        Line2 = p.Field<string>("Line2"),
                        Pincode = p.Field<string>("Pincode"),
                        City = p.Field<string>("City"),
                        State = p.Field<string>("State"),
                        MobileNo = p.Field<string>("MobileNo"),                        
                    })
                    .FirstOrDefault();
            
            
            return matchingAddress;
        }

        public List<ProductContract> GetAllProducts()
        {
            List<ProductContract> products = new List<ProductContract>();

           //Create factory
                DbProviderFactory factory = DbProviderFactories.GetFactory(System.Configuration.ConfigurationManager.ConnectionStrings["GOConnectionString"].ProviderName);

                //Create connection
                DbConnection connection = factory.CreateConnection();
                connection.ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["GOConnectionString"].ConnectionString;

                //Create command
                DbCommand command = connection.CreateCommand();
                command.CommandText = "TeamA.GetAllProducts";
                command.Connection = connection;
                command.CommandType = System.Data.CommandType.StoredProcedure;

                //Create adapter
                DbDataAdapter adapter = factory.CreateDataAdapter();
                adapter.SelectCommand = command;

                //Create dataset
                DataSet ds = new DataSet();

                //Execute
                adapter.Fill(ds);

                //Convert datatable to collection
                products = ds.Tables[0]
             .AsEnumerable()
             .Select(p => new ProductContract()
             {
                 ProductID = p.Field<Guid>("ProductID"),
                 Name = p.Field<string>("Name"),
                 Category = p.Field<string>("Category"),
                 Stock = p.Field<int>("Stock"),
                 Size = p.Field<string>("Size"),
                 Colour = p.Field<string>("Colour"),
                 TechnicalSpecifications = p.Field<string>("TechnicalSpecifications"),
                 CostPrice = p.Field<decimal>("CostPrice"),
                 SellingPrice = p.Field<decimal>("SellingPrice"),
                 DiscountPercentage = p.Field<decimal>("DiscountPercentage")
             })
             .ToList();

           
            return products;
        }

        public List<OrdersDataContract> GetOrdersByRetailerIDDAL(Guid RetailerID)
        {
            List<OrdersDataContract> searchOrder = new List<OrdersDataContract>();
            
                DbProviderFactory factory = DbProviderFactories.GetFactory(System.Configuration.ConfigurationManager.ConnectionStrings["GOConnectionString"].ProviderName);


                DbConnection connection = factory.CreateConnection();

                connection.ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["GOConnectionString"].ConnectionString;

                //Create command
                DbCommand command = connection.CreateCommand();
                command.CommandText = "[13th Aug CLoud PT Immersive].TeamA.GetOrdersByRetailerID";
                command.Connection = connection;
                command.CommandType = System.Data.CommandType.StoredProcedure;

                //Create parameters
                DbParameter p1 = command.CreateParameter();
                p1.ParameterName = "@retailerID";
                p1.Value = RetailerID;
                p1.DbType = System.Data.DbType.Guid;
                command.Parameters.Add(p1);

                //Create adapter
                DbDataAdapter adapter = factory.CreateDataAdapter();
                adapter.SelectCommand = command;

                //Create dataset
                DataSet ds = new DataSet();
                //Execute
                adapter.Fill(ds);

                //Convert datatable to collection
                searchOrder =
                    ds.Tables[0]
                    .AsEnumerable()
                    .Select(p => new OrdersDataContract()
                    {
                        OrderID = p.Field<Guid>("OrderID"),
                        RetailerID = p.Field<Guid>("RetailerID"),
                        SalespersonID = p.IsNull("SalespersonID") ? default(Guid) : p.Field<Guid>("SalespersonID"),
                        TotalQuantity = p.Field<int>("TotalQuantity"),
                        TotalAmount = p.Field<decimal>("TotalAmount"),
                        ChannelOfSale = p.Field<string>("ChannelOfSale"),
                        OrderDateTime = p.Field<DateTime>("OrderDateTime"),
                        ModifiedDateTime = p.Field<DateTime>("ModifiedDateTime")

                    }).ToList();
            
            return searchOrder;
        }

       
        public RetailerDataContract GetRetailerByRetailerIDBL(Guid searchRetailerID)
        {
            //Create factory
            DbProviderFactory factory = DbProviderFactories.GetFactory(System.Configuration.ConfigurationManager.ConnectionStrings["GOConnectionString"].ProviderName);

            //Create connection
            DbConnection connection = factory.CreateConnection();
            connection.ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["GOConnectionString"].ConnectionString;

            //Create command
            DbCommand command = connection.CreateCommand();
            command.CommandText = "TeamA.GetRetailerByRetailerID";
            command.Connection = connection;
            command.CommandType = System.Data.CommandType.StoredProcedure;

            //Create Parameter
            DbParameter param = command.CreateParameter();
            param.ParameterName = "@retailerID";
            param.Value = searchRetailerID;
            param.DbType = System.Data.DbType.Guid;
            command.Parameters.Add(param);

            //Create adapter
            DbDataAdapter adapter = factory.CreateDataAdapter();
            adapter.SelectCommand = command;

            //Create dataset
            DataSet ds = new DataSet();

            //Execute
            adapter.Fill(ds);

            //Convert datatable
            RetailerDataContract retailerWcf = new RetailerDataContract();
            retailerWcf = ds.Tables[0]
               .AsEnumerable()
               .Select(temp => new RetailerDataContract()
               {
                   RetailerID = temp.Field<Guid>("RetailerID"),
                   RetailerName = temp.Field<string>("RetailerName"),
                   RetailerMobile = temp.Field<string>("RetailerMobile"),
                   Email = temp.Field<string>("Email"),
                   RetailerPassword = temp.Field<string>("RetailerPassword")

               })
               .FirstOrDefault();

            return retailerWcf;
        }
    }
}
