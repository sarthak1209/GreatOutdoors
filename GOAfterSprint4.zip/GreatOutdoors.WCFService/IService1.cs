﻿using GreatOutdoors.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;

namespace GreatOutdoors.WCFService
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the interface name "IService1" in both code and config file together.
    [ServiceContract]
    public interface IService1
    {

        [OperationContract]
        Address GetAddressByAddressID(Guid value);


        [OperationContract]
        List<ProductContract> GetAllProducts();

        [OperationContract]
        List<OrdersDataContract> GetOrdersByRetailerIDDAL(Guid RetailerID);

        [OperationContract]
        RetailerDataContract GetRetailerByRetailerIDBL(Guid RetailerID);

        [OperationContract]
        List<ReturnDetailsDataContract> GetReturnDetailsByRetailerIDDAL(Guid RetailerID);
    }

    [DataContract]
    public class ReturnDetailsDataContract
    {
        [DataMember]
        public System.Guid ReturnDetailID { get; set; }
        [DataMember]
        public Nullable<System.Guid> ReturnID { get; set; }
        [DataMember]
        public Nullable<System.Guid> ProductID { get; set; }
        [DataMember]
        public int Quantity { get; set; }
        [DataMember]
        public string ReasonOfReturn { get; set; }
        [DataMember]
        public decimal UnitPrice { get; set; }
        [DataMember]
        public decimal TotalPrice { get; set; }
        [DataMember]
        public Nullable<System.Guid> AddressID { get; set; }


    }




    [DataContract]
    public class AddressContract
    {
        [DataMember]
        public System.Guid AddressID { get; set; }

        [DataMember]
        public System.Guid RetailerID { get; set; }

        [DataMember]
        public string Line1 { get; set; }

        [DataMember]
        public string Line2 { get; set; }

        [DataMember]
        public string City { get; set; }

        [DataMember]
        public string Pincode { get; set; }

        [DataMember]
        public string State { get; set; }

        [DataMember]
        public string MobileNo { get; set; }

        [DataMember]
        public System.DateTime CreationDateTime { get; set; }

        [DataMember]
        public System.DateTime LastModifiedDateTime { get; set; }
    }

    [DataContract]
    public class ProductContract
    {
        [DataMember]
        public Guid ProductID { get; set; }
        [DataMember]
        public string Name { get; set; }
        [DataMember]
        public string Category { get; set; }
        [DataMember]
        public Nullable<int> Stock { get; set; }
        [DataMember]
        public string Size { get; set; }
        [DataMember]
        public string Colour { get; set; }
        [DataMember]
        public string TechnicalSpecifications { get; set; }
        [DataMember]
        public Nullable<decimal> CostPrice { get; set; }
        [DataMember]
        public Nullable<decimal> SellingPrice { get; set; }
        [DataMember]
        public Nullable<decimal> DiscountPercentage { get; set; }


    }

    [DataContract]
    public class OrdersDataContract
    {
        [DataMember]
        public System.Guid OrderID { get; set; }
        [DataMember]
        public Nullable<System.Guid> RetailerID { get; set; }
        [DataMember]
        public Nullable<System.Guid> SalespersonID { get; set; }
        [DataMember]
        public int TotalQuantity { get; set; }
        [DataMember]
        public decimal TotalAmount { get; set; }
        [DataMember]
        public string ChannelOfSale { get; set; }
        [DataMember]
        public Nullable<System.DateTime> OrderDateTime { get; set; }
        [DataMember]
        public Nullable<System.DateTime> ModifiedDateTime { get; set; }
    }


    [DataContract]
    public class RetailerDataContract
    {
        [DataMember]
        public System.Guid RetailerID { get; set; }
        [DataMember]
        public string RetailerName { get; set; }
        [DataMember]
        public string RetailerMobile { get; set; }
        [DataMember]
        public string Email { get; set; }
        [DataMember]
        public string RetailerPassword { get; set; }
        [DataMember]
        public System.DateTime CreationDateTime { get; set; }
        [DataMember]
        public Nullable<System.DateTime> ModifiedDateTime { get; set; }
    }

}