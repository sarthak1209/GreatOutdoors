﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using GreatOutdoors.Mvc.Models;
using GreatOutdoors.Entities;
using Capgemini.GreatOutdoors.BusinessLayer;
using System.Threading.Tasks;
using static System.ValueTuple;

namespace GreatOutdoors.Mvc.Controllers
{
    public class RetailersController : Controller
    {
        // URL: Retailers/Register
        public ActionResult Register()
        {


            //Creating and initailizing view model object
            RetailerViewModel retailerViewModel = new RetailerViewModel();

            return View(retailerViewModel);
        }

        // URL: Retailers/Register
        [HttpPost]
        public async Task<ActionResult> Register(RetailerViewModel retailerVM)
        {
            try
            {
                //create object of retailerBL

                RetailerBL retailerBL = new RetailerBL();

                //create object of retailer Entity Model
                Retailer retailer = new Retailer();

                //storing fields in retailer(Entity)  object form retailerVM object
                retailer.RetailerID = retailerVM.RetailerID;
                retailer.RetailerName = retailerVM.RetailerName;
                retailer.RetailerMobile = retailerVM.RetailerMobile;
                retailer.Email = retailerVM.Email;

                retailer.RetailerPassword = retailerVM.RetailerPassword;


                //call the AddretailerBL method to add retailer
                bool IsAdded = await retailerBL.AddRetailerBL(retailer);
                if (IsAdded)
                {
                    return RedirectToAction("Login", "Login");
                }
                else
                {
                    return Content("Retailer not registered");
                }
            }
            catch (Exception ex)
            {

                return Content(ex.Message);
            }


        }

        //Url:Retailers/Profile
        public async Task<ActionResult> Profile()
        {

            //Creating object of retailersBL
            RetailerBL retailerBL = new RetailerBL();

            //Store Current Retailer Id
            Guid currentRetailerID = (Guid)Session["RetailerID"];

            //Getting current retailer object from retailersBL
            Retailer retailer = await retailerBL.GetRetailerByRetailerIDBL(currentRetailerID);


            //Creating and initailizing view model object
            RetailerViewModel retailerVM = new RetailerViewModel();


            //Migrate (copy) data from EntityModel collection to ViewModel collection
            retailerVM.RetailerID = retailer.RetailerID;
            retailerVM.RetailerName = retailer.RetailerName;
            retailerVM.RetailerMobile = retailer.RetailerMobile;
            retailerVM.Email = retailer.Email;



            //Call view & pass personVM collection to view
            return View(retailerVM);
        }

        //Url: Retailers/Update
        public async Task<ActionResult> Update()
        {
            //Creating object of retailersBL
            RetailerBL retailerBL = new RetailerBL();

            Guid currentRetailerID = (Guid)Session["RetailerID"];

            //Getting current retailer object from retailersBL
            Retailer retailer = await retailerBL.GetRetailerByRetailerIDBL(currentRetailerID);


            //Creating and initailizing view model object
            RetailerViewModel retailerViewModel = new RetailerViewModel()
            {
                RetailerID = currentRetailerID,
                RetailerName = retailer.RetailerName,
                RetailerMobile = retailer.RetailerMobile,
                Email = retailer.Email

            };
            return View(retailerViewModel);
        }

        //Url: Retailers/Update
        [HttpPost]
        public async Task<ActionResult> Update(RetailerViewModel retailerVM2)
        {

            //create retailerBL object 
            RetailerBL retailerBL = new RetailerBL();

            //create object of retailer Entity Model
            Retailer retailer = new Retailer();

            //storing fields in retailer(Entity)  object form retailerVM object
            retailer.RetailerID = retailerVM2.RetailerID;
            retailer.RetailerName = retailerVM2.RetailerName;
            retailer.RetailerMobile = retailerVM2.RetailerMobile;
            retailer.Email = retailerVM2.Email;

            //call the AddretailerBL method to add retailer
            bool IsAdded = await retailerBL.UpdateRetailerBL(retailer);
            if (IsAdded)
            {
                return RedirectToAction("Profile");
            }
            else
            {
                return Content("Retailer not Updated");
            }

        }

        //Url: Retailers/UpdatePassword
        public async Task<ActionResult> UpdatePassword()
        {
            //Creating object of retailersBL
            RetailerBL retailerBL = new RetailerBL();

            Guid currentRetailerID = (Guid)Session["RetailerID"];

            //Getting current retailer object from retailersBL
            Retailer retailer = await retailerBL.GetRetailerByRetailerIDBL(currentRetailerID);


            //Creating and initailizing view model object
            RetailerViewModel retailerViewModel = new RetailerViewModel()
            {
                RetailerID = currentRetailerID,
                RetailerPassword = retailer.RetailerPassword,
         
            };
            return View(retailerViewModel);
        }


        //Url: Retailers/Update
        [HttpPost]
        public async Task<ActionResult> UpdatePassword(RetailerViewModel retailerVM3)
        {

            //create retailerBL object 
            RetailerBL retailerBL = new RetailerBL();

            //create object of retailer Entity Model
            Retailer retailer = new Retailer();

            //storing fields in retailer(Entity)  object form retailerVM object
            retailer.RetailerID = retailerVM3.RetailerID;
            retailer.RetailerPassword = retailerVM3.RetailerPassword;
        

            //call the AddretailerBL method to add retailer
            bool IsAdded = await retailerBL.UpdateRetailerPasswordBL(retailer);
            if (IsAdded)
            {
                return RedirectToAction("Profile");
            }
            else
            {
                return Content("Password not Updated");
            }

        }

    }
}