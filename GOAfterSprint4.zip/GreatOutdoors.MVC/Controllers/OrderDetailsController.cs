﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;
using Capgemini.GreatOutdoors.BusinessLayer;
using Capgemini.GreatOutdoors.Contracts.BLContracts;

using GreatOutdoors.Entities;
using GreatOutdoors.Mvc.Models;

namespace GreatOutdoors.MVC.Controllers
{
    public class OrderDetailsController : Controller
    {

        //if (Convert.ToInt32(Session["count"]) == 1)
        //    Session["count"] = "1";
        //else
        //    Session["count"] = "0";

        // GET: OrderDetails/Create==>URL
        public async Task<ActionResult> Create()
        {
            ////Creating and initializing the view model object
            //OrderDetailsModel oDetailsModel = new OrderDetailsModel()
            //{
            //    ProductID = Guid.Parse("23EC4F90-B453-4439-8953-4F362EC57026"),
            //    OrderID = Guid.Parse("9C15FCB8-9857-4FB9-8FD3-FE15A28C5E15"),
            //    AddressID = Guid.Parse("9AE73E73-DAB6-4BC8-831A-766B8749A064")
            //};

            Session["currRetailer"] = (Guid)Session["RetailerID"];
            OrderDetailsModel oDetailsModel = new OrderDetailsModel();

            IProductBL accessProducts = new ProductBL();
            List<Product> productsFetched = await accessProducts.GetAllProductsBL();
            List<OrderDetailsModel> pFSVM = new List<OrderDetailsModel>();
            foreach (var item in productsFetched)
            {
                OrderDetailsModel pFVm = new OrderDetailsModel()
                {
                    ProductID = item.ProductID,
                    Name = item.Name,
                    Category = item.Category,
                    Stock = item.Stock,
                    Size = item.Size,
                    Colour = item.Colour,
                    TechnicalSpecifications = item.TechnicalSpecifications,
                    SellingPrice = item.SellingPrice,
                    DiscountPercentage = item.DiscountPercentage
                };
                pFSVM.Add(pFVm);
            }
            //Calling view and passing the view model object to view.
            return View(pFSVM);
        }

        public async Task<ActionResult> AddToCart(Guid id)
        {
            IProductBL accessProduct = new ProductBL();
            Product currProduct = await accessProduct.GetProductByProductIDBL(id);

            if (Convert.ToString(Session["currOrderID"]) == Convert.ToString(default(Guid)))
            {
                OrderDetailsModel orderDetailVM = new OrderDetailsModel()
                {
                    TotalQuantity = 1,
                    TotalAmount = 1,
                    ChannelOfSale = "Online"

                };
                orderDetailVM.RetailerID = Guid.Parse(Convert.ToString(Session["currRetailer"]));
                Order currOrder = new Order();
                currOrder.RetailerID = orderDetailVM.RetailerID;
                currOrder.SalespersonID = null;
                currOrder.TotalQuantity = orderDetailVM.TotalQuantity;
                currOrder.TotalAmount = orderDetailVM.TotalAmount;
                currOrder.ChannelOfSale = orderDetailVM.ChannelOfSale;

                //Add order if null
                IOrdersBL accessOrder = new OrderBL();
                (bool isAdded, Guid currOrderID) = await accessOrder.AddOrderBL(currOrder);
                Session["currOrderID"] = Convert.ToString(currOrderID);
                Session["count"] = 1;
            }
            else
                Session["currOrderID"] = Session["currOrderID"];




            OrderDetailsModel showProductModel = new OrderDetailsModel()
            {
                GiftPacking = false,
                CurrentStatus = "In Cart"
            };
            showProductModel.ProductID = id;
            showProductModel.Name = currProduct.Name;
            showProductModel.Size = currProduct.Size;
            showProductModel.Colour = currProduct.Colour;
            showProductModel.Quantity = 1;
            showProductModel.TechnicalSpecifications = currProduct.TechnicalSpecifications;
            showProductModel.DiscountedUnitPrice = Convert.ToDecimal(currProduct.SellingPrice * (1 - (currProduct.DiscountPercentage / 100)));
            IAddressBL accessAddress = new AddressBL();
            List<Address> currRetailerAddresses = await accessAddress.GetAddressByRetailerIDBL(Guid.Parse(Convert.ToString(Session["currRetailer"])));

            //ViewBag.AddressesList = new SelectList(currRetailerAddresses, "AddressID", "Line1");
            List<SelectListItem> items = new List<SelectListItem>();
            foreach (var item in currRetailerAddresses)
            {
                items.Add(new SelectListItem() { Text = $"{item.Line1}, {item.Line2}, {item.City}, {item.State}, {item.Pincode}", Value = Convert.ToString(item.AddressID) });
            }
            ViewBag.AddressesList = items;

            //Get error message (in case rdirection)
            if (TempData["errorMsg"] != null)
            {
                ModelState.AddModelError("x", Convert.ToString(TempData["errorMsg"]));
            }

            return View(showProductModel);
        }

        [HttpPost]
        public async Task<ActionResult> AddToCart(OrderDetailsModel currOrderDetail)
        {
            if (currOrderDetail.Quantity > 10 )
            {
                TempData["errorMsg"] = "Quantity exceeds maximum limit 10";
                return RedirectToAction("AddToCart", new { id = currOrderDetail.ProductID});
            }
            if (currOrderDetail.Quantity <=0)
            {
                TempData["errorMsg"] = "Quantity cannot be 0";
                return RedirectToAction("AddToCart", new { id = currOrderDetail.ProductID });
            }
            else
            {
                OrderDetail newODetail = new OrderDetail();
                newODetail.OrderID = Guid.Parse(Convert.ToString(Session["currOrderID"]));
                newODetail.ProductID = currOrderDetail.ProductID;
                newODetail.Quantity = currOrderDetail.Quantity;
                newODetail.DiscountedUnitPrice = currOrderDetail.DiscountedUnitPrice;
                newODetail.TotalPrice = newODetail.Quantity * newODetail.DiscountedUnitPrice;
                newODetail.GiftPacking = false;
                newODetail.CurrentStatus = "In Cart";
                newODetail.AddressID = currOrderDetail.AddressID;


                IOrderDetailsBL accessorderdetails = new OrderDetailsBL();
                await accessorderdetails.AddOrderDetailsBL(newODetail);

                Session["totalCartValue"] = Convert.ToDecimal(Session["totalCartValue"]) + newODetail.TotalPrice;
                Session["totalQuantityOfCart"] = Convert.ToInt32(Session["totalQuantityOfCart"]) + newODetail.Quantity;
                return RedirectToAction("Create");
            }
        }


        [HttpGet]
        public ActionResult GetTotalCartValue()
        {
            decimal cartMethodValue = Convert.ToDecimal(Session["totalCartValue"]);
            return Json(cartMethodValue, JsonRequestBehavior.AllowGet);
        }

        public async Task<ActionResult> FetchOrderDetails(Guid id)
        {

            if (id == default(Guid))
            {
                return RedirectToAction("Create");
            }
            else
            {
                //OrderDetailsModel cartDetailsLoad = new OrderDetailsModel();
                IOrderDetailsBL accessOrderDetails = new OrderDetailsBL();
                List<OrderDetail> cartDetails = await accessOrderDetails.GetOrderDetailsByOrderIDBL(id);
                if (cartDetails.Count != 0)
                {
                    List<OrderDetailsModel> cartDetailsLoad = new List<OrderDetailsModel>();
                    foreach (var item in cartDetails)
                    {
                        OrderDetailsModel eachOrderDetail = new OrderDetailsModel()
                        {
                            OrderDetailID = item.OrderDetailID,
                            OrderID = item.OrderID,
                            ProductID = item.ProductID,
                            Quantity = item.Quantity,
                            DiscountedUnitPrice = item.DiscountedUnitPrice,
                            TotalPrice = item.TotalPrice,


                        };
                        using (IProductBL accessProducts = new ProductBL())
                        {
                            Product specProd = await accessProducts.GetProductByProductIDBL(eachOrderDetail.ProductID);
                            eachOrderDetail.Name = specProd.Name;
                        }
                        using (IAddressBL accessAddresses = new AddressBL())
                        {
                            eachOrderDetail.AddressID = item.AddressID;
                            List<Address> currAddresses = await accessAddresses.GetAddressByRetailerIDBL(Guid.Parse(Convert.ToString(Session["currRetailer"])));
                            foreach (var addressItem in currAddresses)
                            {
                                if (addressItem.AddressID == eachOrderDetail.AddressID)
                                {
                                    eachOrderDetail.Address = addressItem.Line1 + ", " + addressItem.Line2 + ", " + addressItem.City + ", " + addressItem.State + ", " + addressItem.Pincode;
                                }
                            }
                        }

                        cartDetailsLoad.Add(eachOrderDetail);
                    }
                    return View(cartDetailsLoad);
                }
                else
                    return RedirectToAction("Create");
            }
        }


        public async Task<ActionResult> DeleteOrderDetailfromCart(Guid id)
        {
            Guid currentOrderID=default(Guid);
            Guid ID = (Guid)Session["RetailerID"];
            ServiceReference1.Service1Client ordersServiceClient = new ServiceReference1.Service1Client();
            WCFService.OrdersDataContract[] ordersDC = ordersServiceClient.GetOrdersByRetailerIDDAL(ID);
            foreach (var item in ordersDC)
            {
                if (item.OrderID == Guid.Parse(Convert.ToString(Session["currOrderID"])))
                    currentOrderID = item.OrderID;

            }
            bool isOrderDeleted = false;
            IOrderDetailsBL accessOrderDetails = new OrderDetailsBL();
            List<OrderDetail> orderDetails = new List<OrderDetail>();
            orderDetails = await accessOrderDetails.GetOrderDetailsByOrderIDBL(currentOrderID);
            if (orderDetails.Count != 1)
            {
                foreach (var item in orderDetails)
                {
                    if (item.OrderDetailID == id)
                    {
                        Session["totalCartValue"] = Convert.ToDecimal(Session["totalCartValue"]) - item.TotalPrice;
                        Session["totalQuantityOfCart"] = Convert.ToInt32(Session["totalQuantityOfCart"]) - item.Quantity;
                    }
                }

                isOrderDeleted = await accessOrderDetails.DeleteOrderDetailsBL(id);


                return RedirectToAction("FetchOrderDetails", "OrderDetails", new { id = Guid.Parse(Convert.ToString(Session["currOrderID"])) });
            }
            else
            {
                foreach (var item in orderDetails)
                {
                    if (item.OrderDetailID == id)
                    {
                        Session["totalCartValue"] = Convert.ToDecimal(Session["totalCartValue"]) - item.TotalPrice;
                        Session["totalQuantityOfCart"] = Convert.ToInt32(Session["totalQuantityOfCart"]) - item.Quantity;
                    }
                }

                isOrderDeleted = await accessOrderDetails.DeleteOrderDetailsBL(id);
                Session["totalCartValue"] = 0;
                Session["totalQuantityOfCart"] = 0;
                IOrdersBL accessOrders = new OrderBL();
                await accessOrders.DeleteOrderByOrderID(Guid.Parse(Convert.ToString(Session["currOrderID"])));
                Session["currOrderID"] = default(Guid);
                Session["count"] = 0;

                return RedirectToAction("Create");
            }
        }


        public async Task<ActionResult> EmptyCart() {
            IOrderDetailsBL accessOrderDetails = new OrderDetailsBL();
            List<OrderDetail> orderDetails = new List<OrderDetail>();
            orderDetails = await accessOrderDetails.GetOrderDetailsByOrderIDBL(Guid.Parse(Convert.ToString(Session["currOrderID"])));
            foreach (var item in orderDetails)
            {
                await accessOrderDetails.DeleteOrderDetailsBL(item.OrderDetailID);
            }
            Session["totalCartValue"] = 0;
            Session["totalQuantityOfCart"] = 0;
            IOrdersBL accessOrders = new OrderBL();
            await accessOrders.DeleteOrderByOrderID(Guid.Parse(Convert.ToString(Session["currOrderID"])));
            Session["currOrderID"] = default(Guid);
            Session["count"] = 0;
            return RedirectToAction("Create");
        }

        public async Task<ActionResult> MakePayment() {
            IOrderDetailsBL accessOrderDetails = new OrderDetailsBL();
            
            accessOrderDetails.UpdateOrderDetailStatusBL(Guid.Parse(Convert.ToString(Session["currOrderID"])), "Under Processing");

            IOrdersBL accessOrders = new OrderBL();
            Order confirmOrder = await accessOrders.GetOrderByOrderIDBL(Guid.Parse(Convert.ToString(Session["currOrderID"])));
            confirmOrder.TotalAmount = Convert.ToDecimal(Session["totalCartValue"]);
            confirmOrder.TotalQuantity = Convert.ToInt32(Session["totalQuantityOfCart"]);
            await accessOrders.UpdateOrderBL(confirmOrder);
            Session["currOrderID"] = default(Guid);
            Session["totalCartValue"] = 0;
            Session["totalQuantityOfCart"] = 0;
            Session["count"] = 0;
            return RedirectToAction("Create");

        }

    }
}