﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using Capgemini.GreatOutdoors.Contracts.BLContracts;
using Capgemini.GreatOutdoors.Contracts.DALContracts;
using Capgemini.GreatOutdoors.DataAccessLayer;
using GreatOutdoors.Entities;
using Capgemini.GreatOutdoors.Exceptions;
using Capgemini.GreatOutdoors.Helpers.ValidationAttributes;

namespace Capgemini.GreatOutdoors.BusinessLayer
{
    /// <summary>
    /// Contains data access layer methods for inserting, updating, deleting retailers from Retailers collection.
    /// </summary>
    public class RetailerBL : BLBase<Retailer>, IRetailerBL, IDisposable
    {
        //fields
        RetailerDALBase retailerDAL;

        /// <summary>
        /// Constructor.
        /// </summary>
        public RetailerBL()
        {
            this.retailerDAL = new RetailerDAL();
        }

        /// <summary>
        /// Validations on data before adding or updating.
        /// </summary>
        /// <param name="entityObject">Represents object to be validated.</param>
        /// <returns>Returns a boolean value, that indicates whether the data is valid or not.</returns>
        protected async override Task<bool> Validate(Retailer entityObject)
        {
            //Create string builder
            StringBuilder sb = new StringBuilder();
            bool valid = await base.Validate(entityObject);

            //Email is Unique
            var existingObject = await GetRetailerByEmailBL(entityObject.Email);
            if (existingObject != null && existingObject?.RetailerID != entityObject.RetailerID)
            {
                valid = false;
                sb.Append(Environment.NewLine + $"Email {entityObject.Email} already exists");
            }

            if (valid == false)
                throw new GreatOutdoorsException(sb.ToString());
            return valid;
        }

        /// <summary>
        /// Adds new retailer to Retailers collection.
        /// </summary>
        /// <param name="newRetailer">Contains the retailer details to be added.</param>
        /// <returns>Determinates whether the new retailer is added.</returns>
        public async Task<bool> AddRetailerBL(Retailer newRetailer)
        {
            bool retailerAdded = false;
            try
            {
                if (await Validate(newRetailer))
                {
                    await Task.Run(() =>
                    {
                        this.retailerDAL.AddRetailerDAL(newRetailer);
                        retailerAdded = true;
                        
                    });
                }
            }
            catch (Exception)
            {
                throw;
            }
            return retailerAdded;
        }

        /// <summary>
        /// Gets all retailers from the collection.
        /// </summary>
        /// <returns>Returns list of all retailers.</returns>
        public async Task<List<Retailer>> GetAllRetailersBL()
        {
            List<Retailer> retailersList = null;
            try
            {
                await Task.Run(() =>
                {
                    retailersList = retailerDAL.GetAllRetailersDAL();
                });
            }
            catch (GreatOutdoorsException)
            {
                throw;
            }
            return retailersList;
        }

        /// <summary>
        /// Gets retailer based on RetailerID.
        /// </summary>
        /// <param name="searchRetailerID">Represents RetailerID to search.</param>
        /// <returns>Returns Retailer object.</returns>
        public async Task<Retailer> GetRetailerByRetailerIDBL(Guid searchRetailerID)
        {
            Retailer matchingRetailer = null;
            try
            {
                await Task.Run(() =>
                {
                    matchingRetailer = retailerDAL.GetRetailerByRetailerIDDAL(searchRetailerID);
                });
            }
            catch (GreatOutdoorsException)
            {
                throw;
            }
            return matchingRetailer;
        }

        /// <summary>
        /// Gets retailer based on RetailerName.
        /// </summary>
        /// <param name="retailerName">Represents RetailerName to search.</param>
        /// <returns>Returns Retailer object.</returns>
        public async Task<List<Retailer>> GetRetailersByNameBL(string retailerName)
        {
            List<Retailer> matchingRetailers = new List<Retailer>();
            try
            {
                await Task.Run(() =>
                {
                    matchingRetailers = retailerDAL.GetRetailersByNameDAL(retailerName);
                });
            }
            catch (GreatOutdoorsException)
            {
                throw;
            }
            return matchingRetailers;
        }

        /// <summary>
        /// Gets retailer based on Email and Password.
        /// </summary>
        /// <param name="email">Represents Retailer's Email Address.</param>
        /// <returns>Returns Retailer object.</returns>
        public async Task<Retailer> GetRetailerByEmailBL(string email)
        {
            Retailer matchingRetailer = null;
            try
            {
                await Task.Run(() =>
                {
                    matchingRetailer = retailerDAL.GetRetailerByEmailDAL(email);
                });
            }
            catch (GreatOutdoorsException)
            {
                throw;
            }
            return matchingRetailer;
        }

        /// <summary>
        /// Gets retailer based on Password.
        /// </summary>
        /// <param name="email">Represents Retailer's Email Address.</param>
        /// <param name="password">Represents Retailer's Password.</param>
        /// <returns>Returns Retailer object.</returns>
        public async Task<Retailer> GetRetailerByEmailAndPasswordBL(string email, string password)
        {
            Retailer matchingRetailer = null;
            try
            {
                await Task.Run(() =>
                {
                    matchingRetailer = retailerDAL.GetRetailerByEmailAndPasswordDAL(email, password);
                });
            }
            catch (GreatOutdoorsException)
            {
                throw;
            }
            return matchingRetailer;
        }

        /// <summary>
        /// Updates retailer based on RetailerID.
        /// </summary>
        /// <param name="updateRetailer">Represents Retailer details including RetailerID, RetailerName etc.</param>
        /// <returns>Determinates whether the existing retailer is updated.</returns>
        public async Task<bool> UpdateRetailerBL(Retailer updateRetailer)
        {
            bool retailerUpdated = false;
            try
            {
                if ((await base.Validate(updateRetailer)) && (await GetRetailerByRetailerIDBL(updateRetailer.RetailerID)) != null)
                {
                    this.retailerDAL.UpdateRetailerDAL(updateRetailer);
                    retailerUpdated = true;
                   // Serialize();
                }
            }
            catch (GreatOutdoorsException)
            {
                throw;
            }
            return retailerUpdated;
        }

        /// <summary>
        /// Deletes retailer based on RetailerID.
        /// </summary>
        /// <param name="deleteRetailerID">Represents RetailerID to delete.</param>
        /// <returns>Determinates whether the existing retailer is updated.</returns>
        public async Task<bool> DeleteRetailerBL(Guid deleteRetailerID)
        {
            bool retailerDeleted = false;
            try
            {
                await Task.Run(() =>
                {
                    retailerDeleted = retailerDAL.DeleteRetailerDAL(deleteRetailerID);
                    //Serialize();
                });
            }
            catch (GreatOutdoorsException)
            {
                throw;
            }
            return retailerDeleted;
        }

        /// <summary>
        /// Updates retailer's password based on RetailerID.
        /// </summary>
        /// <param name="updateRetailer">Represents Retailer details including RetailerID, Password.</param>
        /// <returns>Determinates whether the existing retailer's password is updated.</returns>
        public async Task<bool> UpdateRetailerPasswordBL(Retailer updateRetailer)
        {
            bool passwordUpdated = false;
            try
            {
                if ((await Validate(updateRetailer)) && (await GetRetailerByRetailerIDBL(updateRetailer.RetailerID)) != null)
                {
                    this.retailerDAL.UpdateRetailerPasswordDAL(updateRetailer);
                    passwordUpdated = true;
                   // Serialize();
                }
            }
            catch (GreatOutdoorsException)
            {
                throw;
            }
            return passwordUpdated;
        }

        /// <summary>
        /// Disposes DAL object(s).
        /// </summary>
        public void Dispose()
        {
            ((RetailerDAL)retailerDAL).Dispose();
        }

        /// <summary>
        /// Invokes Serialize method of DAL.
        /// </summary>
        //public static void Serialize()
        //{
        //    try
        //    {
        //        Serialize();
        //    }
        //    catch (GreatOutdoorsException)
        //    {
        //        throw;
        //    }
        //}

        /// <summary>
        ///Invokes Deserialize method of DAL.
        /// </summary>
        public static void Deserialize()
        {
            try
            {
                Deserialize();
            }
            catch (GreatOutdoorsException)
            {
                throw;
            }
        }
    }
}



