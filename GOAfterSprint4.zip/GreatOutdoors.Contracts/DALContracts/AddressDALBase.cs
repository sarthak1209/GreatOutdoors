﻿using System;
using System.Collections.Generic;
using System.IO;
using GreatOutdoors.Entities;
using Newtonsoft.Json;

namespace Capgemini.GreatOutdoors.Contracts.DALContracts
{
    /// <summary>
    /// This abstract class acts as a base for AddressDAL class
    /// </summary>
    public abstract class AddressDALBase
    {
        //Collection of Address
        protected static List<Address> addressList = new List<Address>();
        private static string fileName = "address.json";

        //Methods for CRUD operations
        public abstract (Guid,bool) AddAddressDAL(Address newAddress);
        public abstract List<Address> GetAllAddressDAL();
        public abstract List<Address> GetAddressByRetailerIDDAL(Guid searchRetailerID);
        public abstract Address GetAddressByAddressIDDAL(Guid searchAddressID);
        public abstract (Guid,bool) UpdateAddressDAL(Address updateAddress);
        public abstract bool DeleteAddressDAL(Guid deleteAddressID);
      
    }
}