﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace GoWpfForms
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
      
        public MainWindow()
        {
            InitializeComponent();
        }



        public static async Task RetailerRegistration(object sender, RoutedEventArgs e)
        {
            
            


            //    var something = new WindowKiClasskanaamJahaJanaHai();
            //    LoginConstructor(retailer);
            //    something.Show();
            //    this.Close();
            
         
            ///////////
            try
            {
                //Read inputs
                Retailer retailer = new Retailer();
             
                retailer.RetailerName = retailerName.Text.ToString();
             
                retailer.RetailerMobile = retailerMobile.Text.ToString();
                
                retailer.Email = email.Text.ToString();
      
                retailer.Password = retailerPassword.Text.ToString();


                //Invoke AddSystemUserBL method to add
                using (IRetailerBL retailerBL = new RetailerBL())
                {
                    bool isAdded = await retailerBL.AddRetailerBL(retailer);
                    if (isAdded)
                    {
                        WriteLine("Retailer Added");
                    }
                }
            }
            catch (Exception ex)
            {
              
                MessageBox.Show(ex.Message);
            }



            ///////
            return retailer;
        }
    }
}
