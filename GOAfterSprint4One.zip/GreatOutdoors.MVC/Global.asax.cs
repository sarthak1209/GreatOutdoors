﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Optimization;
using System.Web.Routing;

namespace GreatOutdoors.MVC
{
    public class MvcApplication : System.Web.HttpApplication
    {
        protected void Application_Start()
        {
            AreaRegistration.RegisterAllAreas();
            RouteConfig.RegisterRoutes(RouteTable.Routes);
            BundleConfig.RegisterBundles(BundleTable.Bundles);
        }
        public void Session_OnStart()
        {
            Session["count"] = 0;
            Session["currRetailer"] = default(Guid);
            Session["currOrderID"] = default(Guid);
            Session["totalCartValue"] = 0;
            Session["totalQuantityOfCart"] = 0;
        }
    }
}
