﻿using System;
using System.ComponentModel.DataAnnotations;

namespace GreatOutdoors.MVC.Models
{
    public class AddressViewModel
    {
        public Guid AddressID { get; set; }
        public Guid RetailerID { get; set; }

        [Required(ErrorMessage = "Line1 can't be blank")]
        public string Line1 { get; set; }

        [Required(ErrorMessage = "Line2 can't be blank")]
        public string Line2 { get; set; }

        [Required(ErrorMessage = "City can't be blank")]
        [RegularExpression("^[A-Za-z]*$", ErrorMessage ="Please Enter a valid city name")]
        public string City { get; set; }

        [Required(ErrorMessage = "Pincode can't be blank")]
        [RegularExpression("^([0-9]{6})$", ErrorMessage = "Please Enter 6 digit Pincode")]
        public string Pincode { get; set; }

        [Required(ErrorMessage = "Please select a State")]
        public string State { get; set; }

        [Required(ErrorMessage = "Mobile No. can't be blank")]
        [RegularExpression("^(([9876]{1})([0-9]{9}))$", ErrorMessage = "Please enter 10 digit mobile number")]
        public string MobileNo { get; set; }

        public string[] States = { "Andhra Pradesh", "Arunachal Pradesh", "Assam", "Bihar", "Goa"
                                    , "Gujarat","Haryana","Himachal Pradesh ","Jammu & Kashmir","Karnataka",
                                    "Kerala","Madhya Pradesh","Maharashtra","Manipur","Meghalaya","Mizoram",
                                    "Nagaland","Orissa","Punjab","Rajasthan","Sikkim","Tamil Nadu","Tripura",
                                    "Uttar Pradesh","West Bengal","Chhattisgarh","Uttarakhand","Jharkhand","Telangana" };
    }
}